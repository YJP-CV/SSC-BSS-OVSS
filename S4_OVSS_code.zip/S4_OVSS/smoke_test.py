"""Offline end-to-end regression test with a miniature random CLIP."""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from transformers import CLIPConfig, CLIPModel
from transformers.models.clip.tokenization_clip import bytes_to_unicode

from model import BasisBank
from run import main, metrics, pixel_bce


def invoke(*args):
    output = io.StringIO()
    with patch.object(sys, 'argv', ['run.py', *map(str, args)]), contextlib.redirect_stdout(output):
        main()
    return output.getvalue()


def check_math():
    bank = BasisBank(768, 8, 4, 6)
    assert sum(p.numel() for p in bank.parameters()) == 50688
    x = torch.randn(1, 3, 768)
    for site in range(6):
        torch.testing.assert_close(bank(x, site), x + x @ bank.delta(site))
    logits = torch.randn(1, 3, 2, 2)
    ids = torch.tensor([[[0, 1], [2, 255]]])
    target = F.one_hot(ids.clamp_max(2), 3).permute(0, 3, 1, 2).float()
    reference = F.binary_cross_entropy_with_logits(logits, target, reduction='none')
    torch.testing.assert_close(pixel_bce(logits, ids), reference.mean(1)[ids != 255].mean())
    perfect = metrics(torch.eye(3), {'names': ['a','b','c'], 'unseen': ['a']})
    assert perfect['harmonic_mean'] == perfect['mIoU'] == 100.


def check_cli(tmp):
    alphabet = list(bytes_to_unicode().values())
    words = ['<|startoftext|>', '<|endoftext|>'] + alphabet + [c+'</w>' for c in alphabet]
    folder = tmp / 'clip'
    folder.mkdir()
    (folder/'vocab.json').write_text(json.dumps({w:i for i,w in enumerate(words)}))
    (folder/'merges.txt').write_text('#version: 0.2\n')
    cfg = CLIPConfig(projection_dim=16,
                     vision_config=dict(hidden_size=32, intermediate_size=64, num_attention_heads=4,
                                        num_hidden_layers=7, image_size=32, patch_size=8),
                     text_config=dict(hidden_size=32, intermediate_size=64, num_attention_heads=4,
                                      num_hidden_layers=1, vocab_size=len(words), bos_token_id=0,
                                      eos_token_id=1, pad_token_id=1))
    CLIPModel(cfg).save_pretrained(folder)
    Image.fromarray(np.random.default_rng(0).integers(0, 256, (37, 51, 3), dtype=np.uint8)).save(tmp/'image.png')
    ids = np.zeros((37, 51), dtype=np.uint8)
    ids[:, 24:] = 1
    ids[0] = 255
    Image.fromarray(ids).save(tmp/'mask.png')
    vocab = tmp/'names.json'
    vocab.write_text(json.dumps({'names':['road','car'], 'unseen':['car']}))
    manifest = tmp/'pairs.jsonl'
    manifest.write_text(json.dumps({'image':'image.png','mask':'mask.png'}))
    common = ['--device','cpu','--clip',folder,'--vocab',vocab,'--checkpoint',tmp/'head.pt']
    log = invoke('train', *common, '--manifest',manifest,'--epochs',1,'--batch-size',1,
                 '--size',32,48,'--warmup',0)
    assert np.isfinite(json.loads(log)['mean_batch_loss'])
    result = json.loads(invoke('eval', *common, '--manifest',manifest))
    assert 0 <= result['mIoU'] <= 100 and set(result['per_class_IoU']) == {'road', 'car'}
    vocab.write_text(json.dumps({'names':['car','bus','vegetation']}))
    invoke('predict', *common, '--image',tmp/'image.png','--output',tmp/'result.png')
    with Image.open(tmp/'result.png') as mask:
        assert mask.size == (51, 37) and np.asarray(mask).max() < 3


if __name__ == '__main__':
    torch.manual_seed(0)
    torch.set_num_threads(1)
    check_math()
    with tempfile.TemporaryDirectory() as temp:
        check_cli(Path(temp))
    print('PASS: BSS, masked BCE, metrics, train, reload, evaluate, new-vocabulary prediction.')
