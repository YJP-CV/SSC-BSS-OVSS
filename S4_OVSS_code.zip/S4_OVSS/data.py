"""Paired image/index-mask input and CLIP normalization."""
import json
import random
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
import torch
from torch.utils.data import Dataset

BILINEAR = Image.Resampling.BILINEAR
NEAREST = Image.Resampling.NEAREST


def read_vocab(path):
    vocab = json.loads(Path(path).read_text(encoding='utf8'))
    names = vocab['names']
    if not names or len(set(names)) != len(names) or not all(isinstance(n, str) and n.strip() for n in names):
        raise ValueError('Provide distinct, nonempty class names')
    unseen = vocab.get('unseen', [])
    if not set(unseen).issubset(names):
        raise ValueError('Unknown unseen class')
    return vocab


def image_tensor(image, size):
    array = np.asarray(image.resize((size[1], size[0]), BILINEAR), dtype=np.float32) / 255
    tensor = torch.from_numpy(array).permute(2, 0, 1)
    mean = tensor.new_tensor([0.48145466, 0.4578275, 0.40821073])[:, None, None]
    std = tensor.new_tensor([0.26862954, 0.26130258, 0.27577711])[:, None, None]
    return (tensor - mean) / std


class Pairs(Dataset):
    def __init__(self, manifest, vocab, size, training=False):
        path = Path(manifest)
        self.base = path.parent
        self.rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        if not self.rows:
            raise ValueError('Empty manifest')
        self.size, self.training, self.count = size, training, len(vocab['names'])
        self.mapping = vocab.get('raw_to_train')
        if self.mapping and any(int(v) not in (*range(self.count), 255) for v in self.mapping.values()):
            raise ValueError('Invalid destination class in raw_to_train')

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        row = self.rows[idx]
        with Image.open(self.base / row['image']) as src:
            image = src.convert('RGB')
        with Image.open(self.base / row['mask']) as src:
            raw = np.asarray(src)
        if raw.ndim != 2 or image.size != raw.shape[::-1]:
            raise ValueError('Mask must be a single-channel index image aligned with RGB')
        if self.count > 255:
            raise ValueError('Indexed masks support up to 255 classes')
        if self.mapping is None:
            if not np.all(((raw >= 0) & (raw < self.count)) | (raw == 255)):
                raise ValueError('Unknown mask ID. Supply raw_to_train or use contiguous IDs.')
            ids = raw.astype(np.uint8)
        else:
            ids = np.full(raw.shape, 255, np.uint8)
            for k, v in self.mapping.items():
                ids[raw == int(k)] = int(v)
        mask = Image.fromarray(ids)
        if self.training:
            if random.random() < 0.5:
                image, mask = ImageOps.mirror(image), ImageOps.mirror(mask)
            angle = random.uniform(-10, 10)
            image = image.rotate(angle, BILINEAR)
            mask = mask.rotate(angle, NEAREST, fillcolor=255)
            w, h = image.size
            scale = random.uniform(.8, 1.)
            cw, ch = max(1, int(w * scale)), max(1, int(h * scale))
            x, y = random.randint(0, w - cw), random.randint(0, h - ch)
            box = (x, y, x + cw, y + ch)
            image = image.crop(box)
            mask = mask.crop(box).resize(tuple(reversed(self.size)), NEAREST)
        return image_tensor(image, self.size), torch.from_numpy(np.array(mask, dtype=np.int64))
