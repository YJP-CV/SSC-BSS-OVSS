"""Train, evaluate or predict with one locally supplied CLIP checkpoint."""
import argparse
import json
import math
from pathlib import Path
import random

import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from transformers import CLIPModel, CLIPTokenizer

from data import Pairs, image_tensor, read_vocab
from model import Segmenter


def pixel_bce(logits, ids):
    # Sum over binary classes without allocating a dense one-hot target.
    valid = ids != 255
    target = ids.masked_fill(~valid, 0)
    positive = logits.gather(1, target[:, None]).squeeze(1)
    loss = F.softplus(logits).sum(1) - positive
    return loss[valid].sum() / (valid.sum().clamp_min(1) * logits.shape[1])


def lr_at(step, total, warmup):
    if step < warmup:
        return 1e-4 * (step + 1) / warmup
    progress = (step - warmup) / max(1, total - warmup - 1)
    return 1e-6 + .5 * (1e-4 - 1e-6) * (1 + math.cos(math.pi * progress))


def train(args, model, text, vocab, settings):
    pairs = Pairs(args.manifest, vocab, args.size, training=True)
    batches = DataLoader(pairs, batch_size=args.batch_size, shuffle=True, num_workers=args.workers)
    opt = torch.optim.AdamW(model.head.parameters(), lr=1e-4, weight_decay=.01)
    model.train()
    total = args.epochs * len(batches)
    step = 0
    for epoch in range(args.epochs):
        epoch_loss, updates = 0., 0
        for image, target in batches:
            for group in opt.param_groups:
                group['lr'] = lr_at(step, total, args.warmup)
            step += 1
            if not (target != 255).any():
                continue
            opt.zero_grad(set_to_none=True)
            loss = pixel_bce(model(image.to(text.device), text), target.to(text.device))
            loss.backward()
            opt.step()
            epoch_loss += loss.item()
            updates += 1
        if not updates:
            raise ValueError('Epoch has no labeled pixels. Check vocab and mask mapping.')
        print(json.dumps({'epoch': epoch + 1, 'mean_batch_loss': epoch_loss / updates}))
        out = Path(args.checkpoint)
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(out.suffix + '.tmp')
        torch.save({'head': model.head.state_dict(), 'settings': settings,
                    'size': list(args.size), 'prompt': args.prompt}, tmp)
        tmp.replace(out)


def metrics(hist, vocab):
    h = hist.double()
    tp = h.diag()
    union = h.sum(0) + h.sum(1) - tp
    iou = tp / union
    acc = tp / h.sum(1)
    def average(values):
        values = values[values.isfinite()]
        return float(values.mean() * 100) if len(values) else None
    names = vocab['names']
    result = {'mIoU': average(iou), 'mAcc': average(acc),
              'per_class_IoU': {name: average(iou[i:i+1]) for i, name in enumerate(names)}}
    if vocab.get('unseen'):
        unseen = torch.tensor([n in vocab['unseen'] for n in names])
        a, b = average(iou[~unseen]), average(iou[unseen])
        hm = None if a is None or b is None else (2*a*b/(a+b) if a+b else 0.)
        result.update(seen_mIoU=a, unseen_mIoU=b, harmonic_mean=hm)
    return result


@torch.inference_mode()
def evaluate(args, model, text, vocab):
    classes = len(text)
    hist = torch.zeros(classes, classes, dtype=torch.int64)
    for image, mask in Pairs(args.manifest, vocab, args.size):
        scores = model(image[None].to(text.device), text)
        pred = F.interpolate(scores, size=mask.shape, mode='bilinear', align_corners=False).argmax(1)[0].cpu()
        valid = mask != 255
        codes = mask[valid] * classes + pred[valid]
        hist += torch.bincount(codes, minlength=classes**2).reshape(classes, classes)
    print(json.dumps(metrics(hist, vocab), ensure_ascii=False, indent=2))


@torch.inference_mode()
def predict(args, model, text):
    with Image.open(args.image) as src:
        image = src.convert('RGB')
    logits = model(image_tensor(image, args.size)[None].to(text.device), text)
    ids = F.interpolate(logits, size=image.size[::-1], mode='bilinear', align_corners=False).argmax(1)
    if len(text) > 65536:
        raise ValueError('PNG mask supports at most 65536 classes')
    dtype = np.uint8 if len(text) <= 256 else np.uint16
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(ids[0].cpu().numpy().astype(dtype)).save(out, format='PNG')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    for action in ('train', 'eval', 'predict'):
        p = commands.add_parser(action)
        for key in ('clip', 'vocab', 'checkpoint'):
            p.add_argument('--' + key, required=True)
        p.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
        p.add_argument('--size', type=int, nargs=2, metavar=('HEIGHT', 'WIDTH'))
        if action != 'predict':
            p.add_argument('--manifest', required=True)
        if action == 'predict':
            p.add_argument('--image', required=True)
            p.add_argument('--output', required=True)
        if action == 'train':
            p.add_argument('--placement', choices=['both', 'ca', 'sa', 'none'], default='both')
            p.add_argument('--epochs', type=int, required=True)
            p.add_argument('--batch-size', type=int, default=8)
            p.add_argument('--heads', type=int, default=8)
            p.add_argument('--rank', type=int, default=8)
            p.add_argument('--spaces', type=int, default=4)
            p.add_argument('--warmup', type=int, default=500)
            p.add_argument('--seed', type=int, default=0)
            p.add_argument('--workers', type=int, default=0)
            p.add_argument('--prompt', default='A photo of {}.')
    args = parser.parse_args()
    vocab = read_vocab(args.vocab)
    if args.action == 'train':
        if min(args.epochs, args.batch_size, args.heads, args.rank, args.spaces) < 1 or args.warmup < 0:
            parser.error('Invalid training configuration')
        if args.prompt.count('{}') != 1:
            parser.error('Prompt requires one {} placeholder')
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        settings = {k: getattr(args, k) for k in ('placement', 'rank', 'spaces', 'heads')}
        args.size = args.size or (224, 224)
    else:
        checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
        settings = checkpoint['settings']
        args.size = args.size or checkpoint['size']
        args.prompt = checkpoint['prompt']
    encoder = CLIPModel.from_pretrained(args.clip, local_files_only=True)
    if encoder.config.vision_config.num_hidden_layers < 7:
        parser.error('At least seven CLIP vision blocks are required')
    patch = encoder.config.vision_config.patch_size
    if any(n < patch or n % patch for n in args.size):
        parser.error('Both input dimensions must be positive patch-size multiples')
    tokenizer = CLIPTokenizer.from_pretrained(args.clip, local_files_only=True)
    model = Segmenter(encoder, **settings).to(args.device)
    text = model.vocabulary(tokenizer, vocab['names'], args.prompt)
    if args.action == 'train':
        train(args, model, text, vocab, settings)
    else:
        model.head.load_state_dict(checkpoint['head'])
        model.eval()
        if args.action == 'eval':
            evaluate(args, model, text, vocab)
        else:
            predict(args, model, text)


if __name__ == '__main__':
    main()
