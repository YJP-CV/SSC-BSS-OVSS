# S⁴ · 开放词汇语义分割

输入 RGB 图与类别名称，输出原图分辨率的类别索引 PNG。使用冻结的 CLIP ViT-B/16 和可训练的空间自校正头。

## 安装与自检

在本目录运行以下命令。已在 Python 3.12、PyTorch 2.5.1 CPU、Transformers 4.46.3 上通过测试。GPU 环境请先安装与 CUDA 匹配的 PyTorch。

```sh
python -m pip install -r requirements.txt
python smoke_test.py
```

自检构造临时的小型随机 CLIP 和带忽略像素的合成数据，实际运行 train、eval、predict。覆盖非方形输入、检查点重载、原图尺寸恢复、推理词表由两类改为三类、BCE 与显式 one-hot 公式的等价性、BSS 因式计算与显式矩阵乘积的一致性。测试数值没有基准精度含义。

## 准备模型与数据

1. 将 Hugging Face Transformers 格式的**完整 CLIP ViT-B/16**放入本地目录（包括模型配置、模型权重、tokenizer 的 vocab.json 与 merges.txt）。训练、评测、推理必须使用同一份预训练权重。所有命令只读本地模型。
2. 图像配单通道整型标签 PNG。默认标签 0 至 C−1 严格对应词表顺序，255 忽略。调色板 PNG 按索引读取。对 RGB 颜色标签，请先按数据集官方颜色表转换为索引。
3. 每个划分单独准备 JSONL 清单，每行一个样本，路径相对清单目录。训练用 COCO-Stuff 的 171 类语义标注。评测单独使用目标测试集或 Cityscapes 验证集。

```json
{"image":"images/frame_001.jpg","mask":"masks/frame_001.png"}
```

词表 JSON 中 names 为有序类别名。若原始 ID 不连续，可提供 raw_to_train 对象，只映射列出的原始 ID，其余均作为 255 忽略。例如：

```json
{"names":["road","car"],"raw_to_train":{"7":0,"26":1},"unseen":[]}
```

训练词表应使用与实际 COCO-Stuff 标签版本对应的完整 171 类名称及映射，请核对原始 ID 是否已经重映射。configs/cityscapes_trainids.json 对应官方 19 类 labelTrainIds 图。traffic_bus.json 对应论文含 bus 的八类词表，traffic_truck.json 对应含 truck 的八类词表；二者采用论文描述的排列，使用前请按实际标注 ID 设置 raw_to_train。设定 unseen 后，评测程序同时输出 seen/unseen mIoU 与调和平均。

## 训练、评测与预测

下例使用当前目录下的相对路径。训练轮数及输入尺寸是示例选择。256×512 等长宽均为 16 倍数的输入也可使用，脚本插值视觉位置编码。每个检查点仅保存可训练头及其推理配置，省去冻结的 CLIP 权重。再次训练同一输出路径会替换已有检查点。

```sh
python run.py train --clip weights/clip_b16 --vocab data/coco171.json --manifest data/coco_train.jsonl --epochs 20 --batch-size 8 --size 224 224 --seed 0 --checkpoint runs/seed0.pt

python run.py eval --clip weights/clip_b16 --checkpoint runs/seed0.pt --vocab configs/cityscapes_trainids.json --manifest data/city_val.jsonl

python run.py predict --clip weights/clip_b16 --checkpoint runs/seed0.pt --vocab configs/traffic_bus.json --image input.jpg --output prediction.png
```

推理词表可替换成任意自定义 names 列表，PNG 像素值为该列表的从零开始的索引。评测把 logits 双线性插值到原始标注尺寸后取 argmax，跨图像累计混淆矩阵。mIoU 仅平均并集非零的类，mAcc 仅平均真值像素非零的类。所有得分以百分数输出，未定义项为 null。论文三种子实验可分别用 --seed 0、1、2 训练并保存不同检查点，再对三次独立评测结果统计均值和标准差。

## 论文与实现对应

| R1 位置 | 实现 |
|---|---|
model.py 的 Segmenter 提取第 3、7 个视觉块的 patch token，去掉 CLS，拼接后由 MLP 融合。末层逐 patch 投影到文本空间，与归一化文本特征计算初始余弦图。每次运行仅编码一次词表。 |
Correction 以局部特征为 Q、深层特征为 K/V，随后执行自注意力。两层转置卷积恢复空间信息，视觉嵌入与文本向量点积产生逐类校正量，与初始亲和图相加。 |
BasisBank 共享 D、U，每个 Q/K/V 位置分别学习 Q 的混合矩阵。实现直接学习式（8）的 Q，而非额外训练其展开因子。推理和训练均通过小矩阵完成计算。d=768、p=4、r=8、m=6 时共有 50,688 个适配器参数，不含 SSC 其余参数。 |
| §4.2 | 两个编码器冻结并保持 eval 模式。仅训练 SSC 及其 BSS 参数。有效像素上对各类独立计算 BCE，使用 AdamW、学习率 1e−4、权重衰减 0.01、默认 500 次线性预热、余弦退火到 1e−6、批量 8。总迭代数应超过预热长度。 |
placement both、ca、sa、none 控制适配器位置；none 保留 SSC。按论文给定的未见类别划分报告分组指标。 |

