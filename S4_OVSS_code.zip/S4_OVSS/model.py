"""Frozen CLIP patch features, spatial correction and shared low-rank adapters."""
import math

import torch
from torch import nn
from torch.nn import functional as F


class BasisBank(nn.Module):
    """Row-vector convention of Eq. 8. One bank for all active Q/K/V sites."""
    def __init__(self, width, rank, spaces, sites):
        super().__init__()
        self.down = nn.Parameter(torch.randn(spaces, width, rank) / math.sqrt(width))
        self.up = nn.Parameter(torch.randn(spaces, rank, width) * 0.001)
        self.mix = nn.Parameter(torch.eye(rank).repeat(sites, spaces, 1, 1))

    def forward(self, x, site):
        hidden = torch.einsum('bnd,pdr->bnpr', x, self.down)
        mixed = torch.einsum('bnpr,prs->bnps', hidden, self.mix[site])
        return x + torch.einsum('bnps,psd->bnd', mixed, self.up)

    def delta(self, site):
        return (self.down @ self.mix[site] @ self.up).sum(0)


class Attention(nn.Module):
    def __init__(self, width, heads):
        super().__init__()
        if width % heads:
            raise ValueError('Feature width must be divisible by the number of heads')
        self.heads = heads
        self.output = nn.Linear(width, width)

    def forward(self, query, context, bank, offset):
        def project(x, position):
            if offset is not None:
                x = bank(x, offset + position)
            return x.reshape(*x.shape[:2], self.heads, -1).transpose(1, 2)
        q = project(query, 0)
        k = project(context, 1)
        v = project(context, 2)
        out = F.scaled_dot_product_attention(q, k, v)
        return self.output(out.transpose(1, 2).reshape_as(query))


class Correction(nn.Module):
    def __init__(self, width, embedding, heads=8, rank=8, spaces=4, placement='both'):
        super().__init__()
        active = {'none': (), 'ca': ('ca',), 'sa': ('sa',), 'both': ('ca', 'sa')}[placement]
        self.offsets = {stage: i * 3 for i, stage in enumerate(active)}
        self.bank = BasisBank(width, rank, spaces, len(active) * 3) if active else None
        self.fuse = nn.Sequential(nn.Linear(2 * width, width), nn.GELU(), nn.Linear(width, width))
        self.cross = Attention(width, heads)
        self.self_attn = Attention(width, heads)
        self.upsample = nn.Sequential(nn.ConvTranspose2d(width, width // 4, 2, 2),
                                      nn.GELU(), nn.ConvTranspose2d(width // 4, embedding, 2, 2))

    def forward(self, local, deep, grid):
        x = self.cross(self.fuse(local), deep, self.bank, self.offsets.get('ca'))
        x = self.self_attn(x, x, self.bank, self.offsets.get('sa'))
        return self.upsample(x.transpose(1, 2).reshape(x.shape[0], -1, *grid))


class Segmenter(nn.Module):
    def __init__(self, clip, placement='both', heads=8, rank=8, spaces=4):
        super().__init__()
        self.clip = clip.requires_grad_(False).eval()
        cfg = clip.config
        self.head = Correction(cfg.vision_config.hidden_size, cfg.projection_dim,
                               heads, rank, spaces, placement)

    def train(self, mode=True):
        super().train(mode)
        self.clip.eval()
        return self

    @torch.no_grad()
    def vocabulary(self, tokenizer, names, template):
        prompts = [template.format(name) for name in names]
        tokens = tokenizer(prompts, padding=True, return_tensors='pt')
        device = next(self.clip.parameters()).device
        encoded = self.clip.get_text_features(**{k: v.to(device) for k, v in tokens.items()})
        return F.normalize(encoded, dim=-1)

    def forward(self, image, text):
        patch = self.clip.config.vision_config.patch_size
        height, width = image.shape[-2:]
        if height % patch or width % patch:
            raise ValueError('Input dimensions must be multiples of the patch size')
        grid = (height // patch, width // patch)
        with torch.no_grad():
            vision = self.clip.vision_model
            states = vision(image, output_hidden_states=True,
                            interpolate_pos_encoding=True)
            deep = vision.post_layernorm(states.last_hidden_state[:, 1:])
            local = torch.cat([states.hidden_states[i][:, 1:] for i in (3, 7)], dim=-1)
            aligned = F.normalize(self.clip.visual_projection(deep), dim=-1)
            anchor = (aligned @ text.T).transpose(1, 2).reshape(len(image), -1, *grid)
        visual = self.head(local, deep, grid)
        correction = torch.einsum('bdhw,cd->bchw', visual, text)
        anchor = F.interpolate(anchor, size=visual.shape[-2:], mode='bilinear', align_corners=False)
        return F.interpolate(anchor + correction, size=(height, width),
                             mode='bilinear', align_corners=False)
